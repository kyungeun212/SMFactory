package kr.co.softcampus.beans;

public class DataBean2 {

	private String data3;
	private String data4;
	
	public String getData3() {
		return data3;
	}
	public void setData3(String data3) {
		this.data3 = data3;
	}
	public String getData4() {
		return data4;
	}
	public void setData4(String data4) {
		this.data4 = data4;
	}
}
