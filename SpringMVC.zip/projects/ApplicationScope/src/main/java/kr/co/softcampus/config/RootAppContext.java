package kr.co.softcampus.config;

import org.springframework.context.annotation.Configuration;

// 프로젝트 작업시 사용할 bean을 정의하는 클래스
@Configuration
public class RootAppContext {

}
